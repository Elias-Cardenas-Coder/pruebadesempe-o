import { requireAuth } from './guard.js';
import { showNotFound } from './app/views/not_found.js';
import {
  loadLogin,
  loadRegister,
  loadDashboard,
  loadCreateEvent,
  loadEditEvent
} from '/project-root/app/views/loader.js';

const routes = {
  '/login': loadLogin,
  '/register': loadRegister,
  '/dashboard': loadDashboard,
  '/dashboard/events/create': loadCreateEvent,
  '/dashboard/events/edit': loadEditEvent
};

export async function router() {
  let path = window.location.pathname;

  // Elimina el prefijo /project-root si está en Live Server
  path = path.replace(/\/[^/]+(?=\/index\.html$)/, '').replace('/index.html', '');

  const check = requireAuth(path);
  if (check.redirect) {
    window.history.pushState({}, '', check.redirect);
    return showNotFound();
  }
  const view = routes[path] || showNotFound;
  await view();
}

window.onpopstate = router;

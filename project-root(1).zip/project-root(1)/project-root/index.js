import { router } from '/project-root/router.js';

document.addEventListener('DOMContentLoaded', () => {
  router();

  // Intercept anchor clicks SPA‑style
  document.body.addEventListener('click', e => {
    if (e.target.tagName === 'A' && e.target.href.startsWith(window.location.origin)) {
      e.preventDefault();
      const path = e.target.getAttribute('href');
      window.history.pushState({}, '', path);
      router();
    }
  });
});

import { getUser, logout } from '../../storage.js';
import { router } from '../../router.js';

export function renderNavbar() {
  const user = getUser();
  const existing = document.querySelector('nav');
  if (existing) existing.remove();
  if (!user) return;

  const nav = document.createElement('nav');
  nav.innerHTML = `
    <div class="navbar">
      <span>👋 ${user.username} (${user.role})</span>
      <div class="nav-links">
        <a href="dashboard">Dashboard</a>
        ${user.role === 'admin' ? '<a href="dashboard/events/create">Crear Evento</a>' : ''}
        <a href="login" id="logoutBtn">Salir</a>
      </div>
    </div>
    <hr/>
  `;
  document.body.insertBefore(nav, document.body.firstChild);

  document.getElementById('logoutBtn').addEventListener('click', (e) => {
    e.preventDefault();
    logout();
    window.history.pushState({}, '', 'login');
    router();
  });
}

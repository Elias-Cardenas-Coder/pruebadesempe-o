import { isAuthenticated } from './storage.js';
export function requireAuth(path) {
  const publicPaths = ['/login', '/register', '/not_found'];
  if (!isAuthenticated() && !publicPaths.includes(path)) return { redirect: '/not_found' };
  if (isAuthenticated() && publicPaths.includes(path)) return { redirect: 'dashboard' };
  return { allow: true };
}

export async function showNotFound() {
    const res = await fetch('app/views/not_found.html');
    const html = await res.text();
    document.getElementById('app').innerHTML = html;
  }
  
import { saveUser, getUser } from '/project-root/storage.js';
import { login, registerUser } from '../../auth.js';
import { fetchEvents, createEvent, registerToEvent, getEventById, updateEvent, deleteEvent } from '../../events.js';
import { renderNavbar } from '../components/navbar.js';
import { router } from '../../router.js';

export async function loadLogin() {
  const html = await (await fetch('app/views/login.html')).text();
  document.getElementById('app').innerHTML = html;

  document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const user = await login(e.target.username.value, e.target.password.value);
    if (user) {
      saveUser(user);
      window.history.pushState({}, '', 'dashboard');
      router();
    } else {
      alert('Credenciales incorrectas');
    }
  });
}

export async function loadRegister() {
  const html = await (await fetch('app/views/register.html')).text();
  document.getElementById('app').innerHTML = html;

  document.getElementById('registerForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const user = await registerUser(e.target.username.value, e.target.password.value);
    saveUser(user);
    window.history.pushState({}, '', 'dashboard');
    router();
  });
}

export async function loadDashboard() {
  const html = await (await fetch('app/views/dashboard.html')).text();
  document.getElementById('app').innerHTML = html;
  renderNavbar();

  const user = getUser();
  const events = await fetchEvents();
  const list = document.getElementById('eventList');

  list.innerHTML = events.map(ev => {
    let actions = '';
    if (user.role === 'visitor') {
      actions = `<button data-id="${ev.id}" class="inscribirme">Inscribirme</button>`;
    } else {
      actions = `
        <a href="dashboard/events/edit?id=${ev.id}" class="edit">Editar</a>
        <button data-id="${ev.id}" class="delete">Eliminar</button>
      `;
    }
    return `
      <div class="event">
        <h3>${ev.title}</h3>
        <p>${ev.description}</p>
        <p><strong>Capacidad:</strong> ${ev.capacity}</p>
        ${actions}
      </div>
    `;
  }).join('');

  // Acciones
  list.querySelectorAll('.inscribirme').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      await registerToEvent(e.target.dataset.id, user.id);
      alert('Inscrito con éxito');
    });
  });

  list.querySelectorAll('.delete').forEach(btn => {
    btn.addEventListener('click', async (e) => {
      if (confirm('¿Eliminar evento?')) {
        await deleteEvent(e.target.dataset.id);
        router();
      }
    });
  });
}

export async function loadCreateEvent() {
  const html = await (await fetch('app/views/create_event.html')).text();
  document.getElementById('app').innerHTML = html;
  renderNavbar();

  document.getElementById('createEventForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const newEvent = {
      title: e.target.title.value,
      description: e.target.description.value,
      capacity: parseInt(e.target.capacity.value)
    };
    await createEvent(newEvent);
    window.history.pushState({}, '', 'dashboard');
    router();
  });
}

export async function loadEditEvent() {
  const params = new URLSearchParams(window.location.search);
  const id = params.get('id');
  const html = await (await fetch('app/views/edit_event.html')).text();
  document.getElementById('app').innerHTML = html;
  renderNavbar();

  const ev = await getEventById(id);
  const form = document.getElementById('editEventForm');
  form.title.value = ev.title;
  form.description.value = ev.description;
  form.capacity.value = ev.capacity;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const updated = {
      title: form.title.value,
      description: form.description.value,
      capacity: parseInt(form.capacity.value)
    };
    await updateEvent(id, updated);
    window.history.pushState({}, '', 'dashboard');
    router();
  });
}

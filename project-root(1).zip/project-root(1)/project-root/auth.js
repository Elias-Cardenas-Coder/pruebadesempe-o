const API = 'http://localhost:3000';

export async function login(username, password) {
  const res = await fetch(`${API}/users?username=${username}&password=${password}`);
  const users = await res.json();
  return users[0];
}

export async function registerUser(username, password) {
  const res = await fetch(`${API}/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password, role: 'visitor' })
  });
  return await res.json();
}

const API = 'http://localhost:3000';

export async function fetchEvents() {
  const res = await fetch(`${API}/events`);
  return await res.json();
}
export async function createEvent(ev) {
  const res = await fetch(`${API}/events`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(ev)
  });
  return await res.json();
}
export async function getEventById(id) {
  const res = await fetch(`${API}/events/${id}`);
  return await res.json();
}
export async function updateEvent(id, data) {
  const res = await fetch(`${API}/events/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  return await res.json();
}
export async function deleteEvent(id) {
  const res = await fetch(`${API}/events/${id}`, { method: 'DELETE' });
  return res.ok;
}
export async function registerToEvent(eventId, userId) {
  const res = await fetch(`${API}/registrations`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ eventId, userId })
  });
  return await res.json();
}
